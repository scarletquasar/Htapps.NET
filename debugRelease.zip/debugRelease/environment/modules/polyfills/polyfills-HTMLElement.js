if (!HTMLElement) {
    function HTMLElement() {};
}