/*
    bindGlobals - bindGlobals is a way of storing temporary data that needs a unique naming, 
    it is usually used by built-in asynchronous operators.
*/
var bindGlobals = {};